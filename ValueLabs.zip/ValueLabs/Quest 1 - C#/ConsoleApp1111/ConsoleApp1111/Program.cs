﻿Programs program = new Programs();
var concept = program.Method(AllTricks.Parallel);
concept.Tricks();
Console.ReadLine();

public enum AllTricks
{
    StringInterop,
    Lambda,
    Parallel
}


public class Programs
{
    public IConcept Method(AllTricks allTricks) =>
        allTricks switch
        {
            AllTricks.StringInterop => new Concept1(),
            AllTricks.Lambda => new Concept2(),
            AllTricks.Parallel => new Concept3(),
            _ => throw new ArgumentException(message: "invalid enum value", paramName: nameof(allTricks)),
        };
}

public interface IConcept
{
    void Tricks();
}


public class Concept1 : IConcept
{
    private string value;
    public Concept1()
    {
        this.value = "conept is shown";
    }

    public void Tricks()
    {
        Console.WriteLine($"String Interop {this.value} ");
    }
}

public class Concept2 : IConcept
{
    private List<int> value;
    public Concept2()
    {
        this.value = new List<int>() { 10, 20, 30, 40, 50};
    }

    public void Tricks()
    {
        var result = this.value.Where(x => x > 25).Select(x => x/10).ToList();
        foreach(var item in result)
            Console.WriteLine(item);
    }
}

public class Concept3 : IConcept
{
    public Concept3()
    {
    }

    private async void Method1()
    {
        for (int i = 0; i < 10; i++)
        {
            await Task.Delay(100);
            Console.WriteLine($"Method 1 : {i}");
        }
    }

    private async void Method2()
    {
        for (int i = 0; i < 10; i++)
        {
            await Task.Delay(100);
            Console.WriteLine($"Method 2 : {i}");
        }
    }

    public void Tricks()
    {
        Parallel.Invoke(Method1, Method2);
    }
}
